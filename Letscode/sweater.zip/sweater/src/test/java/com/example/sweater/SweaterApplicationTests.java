package com.example.sweater;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SweaterApplicationTests {

	@Test
	void contextLoads() {
	}

}
